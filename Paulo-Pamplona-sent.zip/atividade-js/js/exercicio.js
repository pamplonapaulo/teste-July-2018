(function(){
    'use strict';
    
    var $opt = document.querySelectorAll('[type="radio"]');
    
    for(var i=0;i<$opt.length;i++){
        $opt[i].addEventListener('click', askConfirmation, false);
    }
        
    function askConfirmation(){
      console.log('Confirma seleção de ' + this.closest('label').value + ' ?');
    }
        
})();